package com.nelito.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasswordPolicyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasswordPolicyApplication.class, args);
	}

}
