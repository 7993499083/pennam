package com.nelito.demo.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="password")
public class PasswordPolicy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "policy_profile_name")
	private String policyProfileName;

	@Column(name = "password_complexity")
	private String passwordComplexity;

	public String getPasswordComplexity() {
		return passwordComplexity;
	}

	public void setPasswordComplexity(String passwordComplexity) {
		this.passwordComplexity = passwordComplexity;
	}

	@Column(name = "password_maximum_length")
	private String passwordMaximumLength;

	@Column(name = "consecutive_number")
	private String consecutiveNumber;

	@Column(name = "levinson_validation")
	private String levinsonValidation;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPolicyProfileName() {
		return policyProfileName;
	}

	public void setPolicyProfileName(String policyProfileName) {
		this.policyProfileName = policyProfileName;
	}

	public String getPasswordMaximumLength() {
		return passwordMaximumLength;
	}

	public void setPasswordMaximumLength(String passwordMaximumLength) {
		this.passwordMaximumLength = passwordMaximumLength;
	}

	public String getConsecutiveNumber() {
		return consecutiveNumber;
	}

	public void setConsecutiveNumber(String consecutiveNumber) {
		this.consecutiveNumber = consecutiveNumber;
	}

	public String getLevinsonValidation() {
		return levinsonValidation;
	}

	public void setLevinsonValidation(String levinsonValidation) {
		this.levinsonValidation = levinsonValidation;
	}

}
