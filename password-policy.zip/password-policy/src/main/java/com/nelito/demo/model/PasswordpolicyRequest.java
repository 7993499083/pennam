package com.nelito.demo.model;

import java.util.List;

public class PasswordpolicyRequest {
	private String policyProfileName;
	private List<String> passwordComplexity;
	private String passwordMaximumLength;
	private String consecutiveNumber;
	private String levinsonValidation;

	public String getPolicyProfileName() {
		return policyProfileName;
	}

	public void setPolicyProfileName(String policyProfileName) {
		this.policyProfileName = policyProfileName;
	}

	public List<String> getPasswordComplexity() {
		return passwordComplexity;
	}

	public void setPasswordComplexity(List<String> passwordComplexity) {
		this.passwordComplexity = passwordComplexity;
	}

	public String getPasswordMaximumLength() {
		return passwordMaximumLength;
	}

	public void setPasswordMaximumLength(String passwordMaximumLength) {
		this.passwordMaximumLength = passwordMaximumLength;
	}

	public String getConsecutiveNumber() {
		return consecutiveNumber;
	}

	public void setConsecutiveNumber(String consecutiveNumber) {
		this.consecutiveNumber = consecutiveNumber;
	}

	public String getLevinsonValidation() {
		return levinsonValidation;
	}

	public void setLevinsonValidation(String levinsonValidation) {
		this.levinsonValidation = levinsonValidation;
	}

}
