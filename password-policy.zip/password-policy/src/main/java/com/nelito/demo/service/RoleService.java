package com.nelito.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nelito.demo.entity.Role;
import com.nelito.demo.model.AddRoleRequest;
import com.nelito.demo.model.AddRoleResponse;
import com.nelito.demo.repo.RoleRepository;

@Service
public class RoleService {

	@Autowired
	private RoleRepository roleRepository;

	public ResponseEntity<AddRoleResponse> addRole(AddRoleRequest request) {
		Role role = new Role();
		role.setName(request.getName());
		role.setMessageType(convertListToString(request.getMessageType()));
		role.setCurrencyType(convertListToString(request.getCurrencyType()));
		role.setPasswordPolicy(convertListToString(request.getPasswordPolicy()));

		Role roleResponse = roleRepository.save(role);
		AddRoleResponse addRoleResponse = new AddRoleResponse();
		if (roleResponse != null) {

			addRoleResponse.setResponseCode(200);
			addRoleResponse.setResponseMessage("Role added successfully");
		}

		return new ResponseEntity<>(addRoleResponse, HttpStatus.OK);

	}

	private String convertListToString(List<String> list) {
		String s = "";
		for (String l : list) {
			s = s + l + ",";
		}
		return s;
	}

}
